Description: Emergency call android application

Όνομα Ομάδας: Trial&Error

Μέλη Ομάδας:

 * Kαρράς Γεώργιος
 * Kristo Aurela
 * Τρίγκας Θανάσης
 * Γεώργιού Λεώνιδας
 * Φλώρου Ζώη
Τομέας Ενδιαφέροντος: Smart Cities

Όνομα Εφαρμογής: Report ΙΤ!

Αναλυτική Περιγραφή: 
  Η εφαρμογή “Report It!” είναι μιά εφαρμογή (android application) εκτάκτου ανάγκης χάρη στην οποιά οι ίδιοι οι χρήστες μπορούν να
καλέσουν την Αστυνομία,την Πυροσβεστικη αλλά και το ΕΚΑΒ με έξυπνο και γρήγορο τρόπο.


More info: pimder0991@gmail.com
